<?php
/** Template Name: Blog Template **/
get_header(); 
	$args = array(
		'posts_per_page'   => 5,
		'offset'           => 0,
		'cat'         => '',
		'category_name'    => '',
		'orderby'          => 'date',
		'order'            => 'DESC',
		'include'          => '',
		'exclude'          => '',
		'meta_key'         => '',
		'meta_value'       => '',
		'post_type'        => 'post',
		'post_mime_type'   => '',
		'post_parent'      => '',
		'author'	   => '',
		'author_name'	   => '',
		'post_status'      => 'publish',
		'suppress_filters' => true,
		'fields'           => '',		
	);
$posts_array = get_posts( $args );
//echo "<pre>";
//print_r($posts_array);
//echo "</pre>";
	//echo $post_data_obj->ID; 
?>

<div id="main-content">
		<!-- blog header breadcrumb div start -->	
         <div class="blog_bdc et_pb_section et_pb_section_0 et_pb_with_background et_pb_section_parallax et_section_regular et_pb_section_first" data-padding="0px !important||0px|" style="background:#000000;">
		  <div class="et_parallax_bg" style="background-image: url('http://wow.pebbled.io/nhurford/vertica-sports/1/wp-content/uploads/2019/02/new-breadcrumb-img.jpg'); opacity:0.6;"></div>
			<div class="et_pb_row et_pb_row_0 et_pb_gutters1">
			  <div class="et_pb_column et_pb_column_4_4 et_pb_column_0  et_pb_css_mix_blend_mode_passthrough et-last-child">
				<div class="et_pb_module et_pb_text et_pb_text_0 et_pb_bg_layout_light et_pb_text_align_center">
				<div class="et_pb_text_inner">
					<h1 class="entry-title main_title"><?php the_title(); ?></h1>
				</div>
			</div> <!-- .et_pb_text -->
			</div> <!-- .et_pb_column -->
			</div> <!-- .et_pb_row -->
			</div>
			
		<!-- blog header breadcrumb div end -->	
	<div class="container">
		<div id="content-area" class="clearfix">	
		  <!-- blog list div start -->
	<?php foreach ($posts_array as $key => $post_data_obj){
		$post_ID = $post_data_obj->ID;
		$post_img = get_the_post_thumbnail_url($post_ID);
		$author_meta = get_the_author_meta($post_ID);
		$avatar =  get_avatar_url($author_meta);		
		$avatar_name =  get_the_author($author_meta);		
		$author_name = get_the_author_meta( 'display_name' , $post_data_obj->post_author );
		$form = $post_data_obj->post_date;		
		$to = current_time('Y-m-d', 1);	
	 	$time_ago = human_time_diff( $from, $to );
		
    		$post_view = getPostViews($post_ID);
		
			?>
		   <div class="blog_list">
		      <div class="blog_img">
				  <a href="<?php echo $post_data_obj->guid; ?>"><img src="<?php echo $post_img ?>" alt="" /></a>
		      </div>
		      <div class="blog_des">
		        <div class="blog_hd">
		          <div class="blog_auth_img">
		            <img src="<?php echo $avatar;?>" alt="" />
		          </div>
		            <div class="auth_name"><?php echo $author_name; ?></div>		          
					<div class="blog_date"><?php echo $new_date = date("M d, Y", strtotime($post_data_obj->post_date)); ?></div>
		            <div class="b_time"><?php echo $time_ago; ?></div>
		          </div>
		        <div class="blog_dsbox">
		          <a href="<?php echo $post_data_obj->guid; ?>" class="blog_ttl"><?php echo  $post_data_obj->post_title; ?></a>
		          <div class="blog_desc">
		            <p><?php echo wp_trim_words( $post_data_obj->post_content, 100 ) ?>
		            </p>
		            <div class="bdr_1"></div>
		            <div class="blog_ft">
		               <div class="b_view"><?php echo $post_view; ?></div>
						<div class="b_write_c"><a href="<?php echo $post_data_obj->guid.'#comment-wrap'; ?>">Write a comment</a></div>
		            </div>
		          </div>
		        </div>
		      </div>
		   </div>
	<?php  } ?>
		   <!-- blog list div end -->
		</div> <!-- #content-area -->
	</div> <!-- .container -->

</div> <!-- #main-content -->

<?php get_footer(); ?> 
