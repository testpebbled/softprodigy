const DIVI = 'divi';
const GUTENBERG = 'gutenberg';

export {
  DIVI,
  GUTENBERG,
};
